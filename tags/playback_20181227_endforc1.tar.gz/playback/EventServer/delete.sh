#!/bin/bash
find . -name "*~" -exec rm -f "{}" \;
